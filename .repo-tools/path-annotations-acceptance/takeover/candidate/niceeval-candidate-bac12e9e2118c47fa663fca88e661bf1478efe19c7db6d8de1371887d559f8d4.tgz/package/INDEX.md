# NiceEval AI 文档索引

这是 coding agent 读取 NiceEval 文档的稳定入口，随 npm 包发布，不属于公开文档站。不要根据训练数据、官网或 GitHub `main` 分支猜测 API。

以下路径都相对于包根 `node_modules/niceeval/`。文档位于 `docs-site/zh/`，与当前安装的 NiceEval 版本一起发布。下面的树列出全部随包页面，每行是「路径 — 标题:一句话自述」。分区含义：

- `tutorials/` 第一次跑通和按任务操作；`explanation/` 概念、边界与原理；`reference/` API、CLI 与数据形状的精确事实；`troubleshooting/` 按症状排查失败；`examples/` 真实项目的接入案例。

按当前任务从树里挑 1–3 页读取（通常是一页 tutorial 或 explanation 搭一页 reference）；页面再引用其它概念或参考时，继续读取包内文件。

随包文档目前只有中文。不要为了找英文版而去抓官网或 GitHub——那里的页面可能对应另一个版本，「另一个版本的英文页」比「当前版本的中文页」更危险。中文页读起来没有障碍就直接读；与用户交流仍用用户的语言。

## 按任务路由

- **已有项目要运行或复验。** 先读 `docs-site/zh/tutorials/agent-feedback-loop.mdx`，再按任务从索引树补读 Authoring、接入或 Reference 页面。保留用户已经给出的范围、授权和预算；只有缺少会改变被测目标、运行边界、凭证边界或费用的决定时才提问。
- **只读诊断。** 先读 `docs-site/zh/tutorials/agent-feedback-loop.mdx`，再从索引树选择相关 Troubleshooting 或 Reference 页面。只从 `show`、`query` 或 `view` 收集公开证据；不要修改项目、重跑 Experiment、采用结果或写入 `.niceeval/`。
- **编写或修正评估。** 先读 `docs-site/zh/tutorials/authoring.mdx` 和 `docs-site/zh/tutorials/evaluation-kinds.mdx`；要连接被测对象时再读对应接入教程。评估输入必须覆盖真实业务能力，并能区分被测系统是否完成任务。
- **首次接入。** 读 `docs-site/zh/tutorials/agent-onboarding.mdx`，它拥有探索、必要决策、事件映射和生命周期的完整步骤。

## 帮用户跑通实验

1. **先确认目标和边界。** 读用户项目的 README、依赖、被测入口和现有 NiceEval 文件，确认要评什么真实用例、被测应用怎样启动、使用哪个 Agent / Sandbox / Judge，以及允许的时间和费用。尊重已有授权；只有这些决定仍缺失且会影响正确性、范围或费用时才问。不要用「你好」式占位题代替真实用例；付费模型、全量 benchmark 或批量重跑先征得用户同意。
2. **只读完成当前步骤需要的文档。** 按上方路由和下面的树选择页面；需要精确字段或命令时补读一页 Reference。不要一次加载整站，也不要凭记忆发明 API。
3. **先建立最小闭环。** Adapter 连接真实被测入口，Experiment 明确选择评估用例与运行条件，评估用例覆盖目标产品有区分度的核心任务，不能退化成普通聊天或算术。写代码前确认四条链都能闭合：协议链从 Experiment 到目标响应，核心能力链从真实输入到业务断言，配置链从声明值到 runtime 消费方，生命周期链从启动、进程级凭证和 readiness 到失败清理。先运行 `niceeval exp list`，再用 `niceeval exp <experiment> <eval> --dry` 核对选择、模型、Attempt 数和结果沿用；生命周期或 Sandbox 不明确时用 `niceeval debug <experiment> <eval>` 查看静态计划。
4. **小范围真实运行。** 先跑一条评估用例、一个 Experiment 和足够证明链路的最小 Attempt 数；需要时给预算与并发加保护。保留最后 receipt 的 `createdRunIds` 和 opaque `publicationCutoff`，并查看 `completion`。`createdRunIds` 只列出已创建的 Run；receipt 只交接这次调用，不能单独证明用户任务完成。先用 `niceeval show --run <run-id>` 在终端快速审阅；需要稳定 JSON 时，运行 `niceeval query discover`，再以 versioned request 调用 `niceeval query explain` 或 `niceeval query run`。需要浏览器连续深读时使用 `niceeval view --run <run-id>`。不要只看进程退出码。
5. **交付可复现结果。** 在已获授权和预算内，主动修复执行链的错误并复验受影响范围。合法业务失败要保留并如实报告，不要为全绿改写应用或断言。缺少真实外部条件时，说清缺的是端口、凭证、数据库或模型服务等，并报告阻塞。告诉用户新增或修改了哪些文件、实际运行了什么命令、Run ID、通过/失败/不可用状态和下一步。没有真实运行就明确说明，不把 `--dry`、typecheck 或配置发现说成实验已经跑通。

## 发现并解决问题

1. **从公开入口收集证据。** 选择问题对应的固定 Run；先用 `niceeval show --run <run-id>` 快速找到异常 Attempt，再用 `niceeval show @<locator>` 查看概览，并按提示进入 `--source`、`--execution`、`--timing`、`--usage` 或 `--diff`。需要稳定 JSON 时运行 `niceeval query discover`，再用完整 request 的 `query explain` / `query run` 读取覆盖、Verdict 和 diagnostics。需要浏览器连续深读时用 `niceeval view --run <run-id>`，再从页面导航进入详情。Attempt locator 仍是数据 identity，不是 `view` 的位置参数。不要直接读取或修改 `.niceeval/` 私有文件。
2. **先分类，再修改。** 选择或发现错误查 `exp list` 与 `--dry`；Plugin、Sandbox、Agent、Fixture 顺序查 `debug`；基础设施和保留现场查 Troubleshooting；Judge 不可用先验证模型、密钥和端点；`failed` 只表示影响 Verdict 的断言未满足，不自动证明被测结果违背任务。`errored`、`skipped`、`not-dispatched` 与 `unavailable` 不能当成零分或普通失败。
3. **修产生错误的那一层。** 处理 `failed` 时，先比较任务允许的结果、实际产物及证据和断言条件。被测应用行为错就修应用；事件或用量映射错就修 Adapter；产物满足任务而断言拒绝了任务允许的结果，就修评估用例；Provider、凭据或生命周期错就修运行配置。已有授权和预算内主动修复执行错误并复验；只读请求不修改。不要通过任意放宽断言、伪造事件或改历史 Record 让结果变绿。
4. **只复验受影响范围。** 修改后重复同一条精确选择命令。默认结果沿用会跳过身份仍匹配的结果；需要重验失败项用 `--rerun`，需要重验全部选中位置才用 `--rerun all`。只有在身份变化但历史证据经人工核对仍然有效时，才用 `niceeval accept` 明确发布新的采用 Run。
5. **闭环验证。** 用新 Run ID 再次运行同一固定 Inspection request，确认分母不变、原 diagnostic 消失且没有新增错误；需要比较修复前后时，以两个明确 Run ID 构造 `runs.compare` request，或在人类审阅时交给 `view`，不要用「最新」代替实验边界。

<!-- GENERATED:BEGIN bundled-docs-tree -->

<!-- 本文件是构建产物(pnpm run build:index),勿手改:树区文案改对应页面的 frontmatter title/description,导语改 INDEX.template.md(生成逻辑见 packages/repo-tools/src/docs/reference-compiler.ts) -->

## `docs-site/zh/tutorials/`

- `docs-site/zh/tutorials/accept-results.mdx` — 审阅并采用历史 Attempt:从 --dry 取得候选 locator，核对不可变 Attempt，再用 niceeval accept 原子采用明确结果，并用新 Run ID 验证分母与来源。
- `docs-site/zh/tutorials/agent-feedback-loop.mdx` — 让 Coding Agent 根据结果迭代:让 Coding Agent 读取 receipt 的 createdRunIds，查看结果，再区分被测失败、证据错误与评估用例误判。
- `docs-site/zh/tutorials/agent-onboarding.mdx` — Coding Agent 从零接入项目:给 Coding Agent 的完整接入流程：探索项目、与用户确认路径、配置 Judge、写出 Adapter、Experiment 与评估用例，并跑通第一个实验。
- `docs-site/zh/tutorials/authoring.mdx` — 编写评估用例: 单轮、多轮和测试集模式:用 defineEval 编写评估用例，包括单轮对话、多轮对话、数据驱动测试、Sandbox Workspace 和评估的生命周期与 Fixture。
- `docs-site/zh/tutorials/ci-integration.mdx` — 在 CI 中运行 NiceEval:让 CI 使用退出状态判定门禁，保留最后的 receipt，并向平台提供 JUnit 文件。
- `docs-site/zh/tutorials/compare-runs.mdx` — 比较多个固定 Run:用 `runs.compare` operation 比较明确 Run 的已发布事实，并在浏览器中审阅相同的结果。
- `docs-site/zh/tutorials/concurrency.mdx` — 调好并发：吞吐、共享状态与固定执行顺序:全局并发、实验上限与 Provider capacity 共同限制实际吞吐。这一页说明排队状态、共享状态与固定顺序。
- `docs-site/zh/tutorials/configuration.mdx` — 把配置和密钥各放到该放的地方:跑几次、超时、并发、judge 这些值写进代码的哪一层，API key 和 provider token 用哪些环境变量。
- `docs-site/zh/tutorials/connect-otel.mdx` — OTel 接入:把应用已有的 OTel span 发送给 NiceEval，在 niceeval view 中查看每轮调用瀑布图。评估用例断言仍以 Send 返回的事件和用量为准。
- `docs-site/zh/tutorials/connect-your-agent.mdx` — 接入你的 Agent:写一个 Adapter、配置一个 Experiment，并运行第一条评估用例。再把配置和参数从 Experiment 传给 Adapter 与被测应用。
- `docs-site/zh/tutorials/control-run-cost.mdx` — 控制一次运行的成本:用 attempts、首过即停、budget、并发和结果沿用分别控制统计样本、停止派发、花费保护与资源占用。
- `docs-site/zh/tutorials/criteria-files.mdx` — 隐藏测试判分：让判据文件进缓存 fingerprint:用 loadText 在模块顶层读入隐藏测试、跑测脚本等判据文件，文件内容进入 fingerprint：改一字节自动重跑，不靠人工 --rerun。
- `docs-site/zh/tutorials/custom-application.mdx` — 评估自定义 LLM 应用:保留应用自己的方法与上下文，用 NiceEval 评估生成内容、社交互动和游戏步骤。
- `docs-site/zh/tutorials/dataset-fanout.mdx` — 数据驱动测试（dataset fan-out）：用多份数据运行同一套评估用例:从 .eval.ts 文件导出数组或 keyed record，将一套评估逻辑展开为多个 case。用 loadYaml 或 loadJson 读取外部测试集，并获得稳定 ID。
- `docs-site/zh/tutorials/debug-lifecycle-plan.mdx` — 运行前检查 Sandbox 计划:用 niceeval debug 查看 Experiment、评估组、评估用例与 Agent 的实际 action 顺序和数值，而不创建运行资源。
- `docs-site/zh/tutorials/docker-in-docker.mdx` — 让 Sandbox 使用 Docker:根据任务信任边界选择 Docker socket、raw privileged DinD 或受管 rootless DinD，并为 Agent 准备 Docker CLI 与 daemon。
- `docs-site/zh/tutorials/eval-groups.mdx` — 用评估组复用 Sandbox:用 defineEvalGroup 显式声明兼容成员：同组按稳定 ID 串行复用一台 Sandbox，不同组继续并行，并把公共准备放到正确的 Sandbox Layer。
- `docs-site/zh/tutorials/evaluation-kinds.mdx` — 通过制与计分制评估:用 defineEval 与 defineScoreEval 编写通过制和计分制评估，调用即登记 Assertion。
- `docs-site/zh/tutorials/experiments.mdx` — 实验矩阵：用运行矩阵比较 agents 和 models:使用 NiceEval experiments 让同一批评估用例横跨多个 agents、models 和 flags，比较 pass rate、成本和延迟。
- `docs-site/zh/tutorials/fixtures.mdx` — Sandbox Fixture：用任务评估 coding agents:用 .eval.ts 给 coding agent 准备隔离 workspace、发送真实任务，并用 Sandbox 文件、命令、diff 和 judge 验证结果。
- `docs-site/zh/tutorials/handle-execution-failures.mdx` — 在基础设施失败时停止无效运行:读懂自动重试，为确定性故障声明影响范围，修复后继续未完成的评估。
- `docs-site/zh/tutorials/install-custom-sandbox-agent.mdx` — 为自定义 Sandbox Agent 安装 CLI:用 ensure 和 installer 检查、安装并复检自定义 coding-agent CLI 的精确版本。
- `docs-site/zh/tutorials/nixos-managed-dind.mdx` — 在 NixOS 上配置 Managed DinD:使用 NiceEval 的 NixOS module 部署 managed rootless Docker profile，并通过 doctor 验证宿主环境。
- `docs-site/zh/tutorials/plugins.mdx` — 用 Plugin 复用完整运行条件:用 definePlugin 组合宿主生命周期与 command-only SandboxLayer，并在多个 owner 之间复用。
- `docs-site/zh/tutorials/quickstart.mdx` — 为你的 Agent 项目设置评估:安装 NiceEval，写三个文件，10 分钟内对你自己的应用跑通第一条评估用例。
- `docs-site/zh/tutorials/reporters.mdx` — 将当前运行接入外部系统:使用 Reporter、JUnit 和 receipt 把当前 Invocation 的信息交给外部系统，同时保持 Record 的所有权边界。
- `docs-site/zh/tutorials/rerun-and-cache.mdx` — 重跑与沿用结果:查看每个 slot 会执行、自动采用还是由操作者接受，并理解这些关系怎样进入 Record。
- `docs-site/zh/tutorials/sandbox-agent.mdx` — Sandbox Agent：评估 Claude Code、Codex 和 bub:使用 NiceEval 内置 agents 或自定义 adapter，在 Docker 或云端 sandbox 中运行 coding-agent CLI。
- `docs-site/zh/tutorials/sandbox-providers.mdx` — Sandbox:官方 Sandbox Docker、Vercel 或 E2B Provider。通过预制快照加速评估
- `docs-site/zh/tutorials/sandbox-reuse.mdx` — 在一批评估中复用 Sandbox:在 Experiment 里声明 sandboxReuse 让多条 Attempt 共用 Sandbox，让 before/after 可安全重放，并配好 lifetimeMs。无法安全保留状态时改用并发。
- `docs-site/zh/tutorials/select-and-preview.mdx` — 选择并预览运行范围:先列出 Experiment，再用路径、评估用例前缀和 tag 收窄范围，最后用 --dry 确认计划后再花费模型与 Sandbox 成本。
- `docs-site/zh/tutorials/verify-judge.mdx` — 配置并验证 Judge:连接 OpenAI 兼容 Judge 网关，用一条最小评估真实预检和判分，再从结果区分配置缺失、网络失败与低质量输出。
- `docs-site/zh/tutorials/viewing-results.mdx` — 查看运行结果:在终端用 show 逐层查看结果；在浏览器用 View 审阅，在自动化中用 query 读取 JSON。
- `docs-site/zh/tutorials/write-experiment.mdx` — 实验与生命周期:如何写好实验。选择 Agent、传递 model 和 flags，设置 attempts、预算、并发与 Sandbox，并用 setup / teardown 起停实验级共享服务。
- `docs-site/zh/tutorials/write-send.mdx` — 编写 Send:分七步编写 Adapter 的 send 函数：发送消息、续接会话、记录用量、映射工具事件、处理人工介入（HITL）、接入 OTel trace，并透传 Experiment flags。

## `docs-site/zh/explanation/`

- `docs-site/zh/explanation/adapter.mdx` — Adapter：把 Agent 接入 NiceEval:Adapter 是你写的适配器。本文讲清楚 send 函数传入什么返回什么、被测系统配置怎么传、三个接入等级，以及 t 上的能力从哪来。
- `docs-site/zh/explanation/assert.mdx` — NiceEval Assertion 与 Match:用 Match 描述值比较，调用即登记 Assertion；handle 只配置同一条 Assertion。
- `docs-site/zh/explanation/drive.mdx` — NiceEval 里怎么驱动 agent：send、session 与 HITL:t.send() 和它返回的 Turn、t.sendFile()、多轮对话、t.newSession()，以及 respond() 处理的人工介入(HITL)。
- `docs-site/zh/explanation/evals.mdx` — NiceEval 中的评估用例：生命周期、verdict 与文件:评估用例是一个测试用例：描述和 test 函数，agent-neutral。了解评估用例如何被发现、调度、评分和报告。
- `docs-site/zh/explanation/experiment.mdx` — 实验（Experiment）：评谁、怎么跑:Experiment 是可签入的运行配置：同一批评估用例对着哪个 agent、哪个模型、开哪些 flags、跑几次。评估用例与 experiment 分开的原因——晚绑定，让同一份评估用例换着对象跑。
- `docs-site/zh/explanation/hitl.mdx` — 人工介入（HITL）：停轮、回答、继续:什么是 Human-in-the-loop，Claude Code / Codex / AI SDK 应用里它长什么样。NiceEval 如何把它变成可评的路径——waiting 停轮、input.requested 说明在等什么、t.respond 替人回答后同一轮继续。
- `docs-site/zh/explanation/judge.mdx` — NiceEval 里的 Judge：评开放式输出:用 `check({ input, output }, factory(...))` 登记 Judge Assertion，并配置阈值或分数。
- `docs-site/zh/explanation/overview.mdx` — NiceEval 的运行后数据流:理解 Record、固定 Inspection operation、Query、Show 和 View 的职责边界。
- `docs-site/zh/explanation/record.mdx` — Record:了解 canonical SQLite Record 的写入、携带与读取边界。
- `docs-site/zh/explanation/runner.mdx` — 运行、封口与读取:了解 Runner 如何发布 Run，以及读取路径为什么只看已封口事实。
- `docs-site/zh/explanation/tier.mdx` — 接入等级（Tier）：三级投入，三组能力:按「Adapter 接到哪里、额外拿到什么观测数据」接入分三级：Tier 1 只接 send，Tier 2 加 OTel，Tier 3 侵入改造暴露 experiment flags。每档买到什么、什么时候升级。

## `docs-site/zh/reference/`

- `docs-site/zh/reference/builtin-agents.mdx` — 内置 Agent 能力参考:NiceEval 内置的 claude-code、codex、bub 适配器分别做到了哪些能力，对应哪些断言，以及已知限制。
- `docs-site/zh/reference/capabilities.mdx` — 能力与证据覆盖参考:Agent 的构造方式、运行时行为与必填的六通道 evidenceCoverage 声明，怎样共同决定 NiceEval 的断言能相信什么。
- `docs-site/zh/reference/cli.mdx` — CLI:用固定的 query、show 和 view 读取 canonical SQLite Record。
- `docs-site/zh/reference/define-agent.mdx` — defineAgent 和 defineSandboxAgent：Adapter 参考:defineAgent 和 defineSandboxAgent 参考：AgentContext、AgentSession、Sandbox 接口和共享 Sandbox 辅助函数。
- `docs-site/zh/reference/define-config.mdx` — defineConfig：项目默认配置:defineConfig 参考：judge、reporters、并发、超时和 sandbox 默认值。
- `docs-site/zh/reference/define-eval.mdx` — defineEval：声明、配置并运行 NiceEval 评估用例:defineEval 参考：选项、test context t、Turn 返回值、Sandbox 辅助函数，以及数组和 keyed record 测试集导出。
- `docs-site/zh/reference/events.mdx` — 标准事件流参考:StreamEvent 的十种事件：每种的字段、什么时候吐、哪些断言消费它。adapter 的核心工作就是产出这条流。
- `docs-site/zh/reference/expect.mdx` — niceeval/expect Match 参考:niceeval/expect 的纯 Match factory：组合文字、结构、条件，再交给 t.check 登记 Assertion。
- `docs-site/zh/reference/official-adapters.mdx` — 官方适配器一览:NiceEval 内置的 Sandbox 和非 Sandbox 适配器分别是什么、怎么鉴权，Sandbox 型里怎么装 MCP server、Skill、插件，怎么使用 Agent 官方配置文件。

## `docs-site/zh/troubleshooting/`

- `docs-site/zh/troubleshooting/debug-sandbox.mdx` — 保留 Sandbox 现场排查问题:用 --keep-sandbox 把失败 Attempt 的 Sandbox 保留成可随时唤醒的现场，用 niceeval sandbox enter 进去手动排查，用 sandbox list / stop 查看和清理。
- `docs-site/zh/troubleshooting/debugging.mdx` — 排查已封口的结果:根据具名错误和闭合 Inspection result，通过 Show、Query 与 View 排查问题。
- `docs-site/zh/troubleshooting/recover-after-kill.mdx` — 运行被强杀后恢复:进程被 kill -9、CI 超时或断电中断后，保留已发布结果、收口失去 owner 的 Run，并收回遗留 Sandbox。

## `docs-site/zh/examples/`

- `docs-site/zh/examples/ai-agent-application.mdx` — 自写 Adapter 评估 AI Agent 应用:一个可运行的 AI SDK v6 Web Agent 评测项目，覆盖自写 Adapter、工具调用、图片理解、多轮会话、模型对比和双路可观测。
- `docs-site/zh/examples/coding-agent-extensions.mdx` — 评估 Coding Agent 扩展:用真实 Workspace 和基线 Experiment，评估 Skill、提示词与 Plugin Benchmark 是否改善 Coding Agent 的任务结果。
- `docs-site/zh/examples/integrations/ai-sdk-v7.mdx` — AI SDK v7 如何非侵入式接入 NiceEval:一个 AI SDK v7 聊天应用，对着它的 HTTP 接口无侵入接入 NiceEval 前后的完整代码 diff：应用侧一行没改。
- `docs-site/zh/examples/integrations/claude-sdk.mdx` — Claude Agent SDK 如何非侵入式接入 NiceEval:一个 Claude Agent SDK 助手后端，接入 NiceEval 前后的完整代码 diff：应用侧一行没改，全部新增在评估用例侧。
- `docs-site/zh/examples/integrations/codex-sdk.mdx` — Codex SDK 如何非侵入式接入 NiceEval:一个 Codex SDK（目录里的编码 agent）后端，接入 NiceEval 前后的完整代码 diff：应用侧一行没改。
- `docs-site/zh/examples/integrations/langgraph.mdx` — LangGraph 如何非侵入式接入 NiceEval:一个纯 Python LangGraph + LangSmith OTel 导出的应用，接入 NiceEval 前后的完整代码 diff。
- `docs-site/zh/examples/integrations/pi-sdk.mdx` — pi-agent-core 如何非侵入式接入 NiceEval:一个 pi-agent-core(@earendil-works)助手后端，接入 NiceEval 前后的完整代码 diff：应用侧只加了一个 devDependency。

<!-- GENERATED:END bundled-docs-tree -->

## 版本规则

- 安装后只从本索引进入包内文档。官网适合安装前了解产品，不是安装版本的 API 事实源。
- 升级 `niceeval` 后重新运行 `niceeval init`，刷新项目里的托管指引。
- 如果某个路径不存在，先重新读取本文件。不要自行推测替代文件名或旧 API。
