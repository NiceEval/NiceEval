import { repositoryRoot } from "./root.js";
import { NodeRuntime, NodeServices } from "@effect/platform-node";
import { OwnedProcessLive } from "./host.js";
import { Argument as Args, Command, Flag as Options } from "effect/unstable/cli";
import { Clock, Data, Effect, FileSystem, Layer, Option } from "effect";

import { linkDownstreamCandidate } from "./downstream/index.js";
import {
  designCommandContribution,
  diffCodeCommandContribution,
  featureCommandContribution,
  generateBundledIndex,
  makeDocsCommand,
  referenceCommandContribution,
  researchCommandContribution,
  siteCommandContribution,
  termsCommandContribution,
  testCommandContribution,
  traceCommandContribution,
  type TerminalDelivery,
  useCaseCommandContribution,
  workCommandContribution,
} from "./docs/index.js";
import { checkExamples, syncExamples } from "./examples/index.js";
import { FEEDBACK_CLOSURE_KINDS, FEEDBACK_MEMORY_RELATION_KINDS, NodeFeedbackStoreLive, runFeedbackCommand } from "./feedback/index.js";
import { MEMORY_KINDS, NodeMemoryStoreLive, PROBLEM_RESOLUTION_KINDS, runMemoryCommand } from "./memory/index.js";
import {
  makeNodePrLive,
  PR_BODY_CASE_DIRECTIONS,
  PR_BODY_CASE_SECTIONS,
  PR_BODY_TERMINOLOGY_DIRECTIONS,
  prBodyCommandContribution,
} from "./pr/index.js";
import {
  acceptPreview,
  buildPreview,
  canonicalJson,
  type PreviewError,
  renderPreviewError,
} from "./preview/index.js";
import { checkRepository, setupRepositoryEnvironment } from "./repository/index.js";

const ROOT = repositoryRoot();

class CliInputError extends Data.TaggedError("CliInputError")<{
  readonly path: string;
  readonly message: string;
}> {}

const jsonOption = Options.boolean("json").pipe(
  Options.withDefault(false),
  Options.withDescription("Emit the complete structured outcome as JSON."),
);
const dryRunOption = Options.boolean("dry-run").pipe(
  Options.withDefault(false),
  Options.withDescription("Validate and return the planned outcome without writing."),
);
const inputOption = Options.string("input").pipe(
  Options.withDescription("Path to a JSON input document."),
);

function readText(path: string) {
  if (path === "-") {
    return Effect.callback<string, CliInputError>((resume) => {
      let source = "";
      const onData = (chunk: string | Buffer) => { source += chunk.toString(); };
      const onEnd = () => resume(Effect.succeed(source));
      const onError = (error: Error) => resume(Effect.fail(new CliInputError({ path, message: String(error) })));
      process.stdin.setEncoding("utf8");
      process.stdin.on("data", onData);
      process.stdin.once("end", onEnd);
      process.stdin.once("error", onError);
      return Effect.sync(() => {
        process.stdin.off("data", onData);
        process.stdin.off("end", onEnd);
        process.stdin.off("error", onError);
      });
    });
  }
  return Effect.flatMap(FileSystem.FileSystem, (fs) => fs.readFileString(path)).pipe(
    Effect.mapError((error) => new CliInputError({ path, message: String(error) })),
  );
}

function readJson(path: string) {
  return readText(path).pipe(Effect.flatMap((source) => Effect.try({
    try: () => JSON.parse(source) as unknown,
    catch: (error) => new CliInputError({
      path,
      message: error instanceof Error ? error.message : String(error),
    }),
  })));
}

function deliverTerminal(delivery: TerminalDelivery) {
  return Effect.sync(() => {
    if (delivery.stdout !== "") process.stdout.write(delivery.stdout);
    if (delivery.stderr !== "") process.stderr.write(delivery.stderr);
    if (delivery.exitCode !== 0) process.exitCode = delivery.exitCode;
  });
}

function resultOk(value: unknown): boolean {
  if (typeof value !== "object" || value === null) return true;
  const record = value as Record<string, unknown>;
  if (typeof record.ok === "boolean") return record.ok;
  return record.receipt === undefined ? true : resultOk(record.receipt);
}

function emit(
  value: unknown,
  json: boolean,
  rendered?: string,
  exitCode = resultOk(value) ? 0 : 1,
) {
  const record = typeof value === "object" && value !== null
    ? value as Record<string, unknown>
    : undefined;
  const human = typeof record?.summary === "string"
    ? `${record.summary}\n`
    : `${JSON.stringify(value, null, 2)}\n`;
  const output = json ? `${JSON.stringify(value, null, 2)}\n` : rendered ?? human;
  return deliverTerminal({ stdout: output, stderr: "", exitCode });
}

function renderUnhandledError(error: unknown): string {
  if (typeof error === "object" && error !== null) {
    const tagged = error as {
      readonly _tag?: unknown;
      readonly detail?: unknown;
      readonly message?: unknown;
      readonly receipt?: { readonly problems?: unknown };
    };
    const name = typeof tagged._tag === "string"
      ? tagged._tag
      : error instanceof Error
        ? error.name
        : "RepositoryToolError";
    const message = typeof tagged.detail === "string" && tagged.detail.length > 0
      ? tagged.detail
      : typeof tagged.message === "string" && tagged.message.length > 0
        ? tagged.message
        : undefined;
    if (message !== undefined) return `${name}: ${message}`;
    if (Array.isArray(tagged.receipt?.problems) && tagged.receipt.problems.length > 0) {
      return `${name}: ${tagged.receipt.problems.map(String).join("; ")}`;
    }
    try {
      return `${name}: ${JSON.stringify(error, null, 2)}`;
    } catch {
      return String(error);
    }
  }
  return String(error);
}

const feedbackImport = Command.make("import", {
  envelope: Options.string("envelope").pipe(Options.withDescription("Feedback envelope JSON path, or - for stdin.")),
  artifacts: Options.string("artifacts").pipe(Options.withDescription("Envelope artifact directory.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ artifacts, dryRun, envelope, json }) => readJson(envelope).pipe(
  Effect.flatMap((value) => runFeedbackCommand({
    operation: "import",
    envelope: value,
    artifacts,
    dryRun,
  })),
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Import one verified downstream Feedback envelope."));

const feedbackExport = Command.make("export", {
  id: Args.string("feedback-id"),
  json: jsonOption,
}, ({ id, json }) => runFeedbackCommand({ operation: "export", id }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Export one Feedback document."));

const feedbackList = Command.make("list", {
  pattern: Args.string("pattern").pipe(Args.optional),
  json: jsonOption,
}, ({ json, pattern }) => runFeedbackCommand({
  operation: "list",
  pattern: Option.getOrUndefined(pattern),
}).pipe(Effect.flatMap((outcome) => emit(outcome, json)))).pipe(
  Command.withDescription("List Feedback, optionally filtered by text."),
);

const feedbackShow = Command.make("show", {
  id: Args.string("feedback-id"),
  json: jsonOption,
}, ({ id, json }) => runFeedbackCommand({ operation: "show", id }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Show one Feedback document."));

const feedbackLink = Command.make("link", {
  id: Args.string("feedback-id"),
  memory: Options.string("memory"),
  kind: Options.choice("kind", FEEDBACK_MEMORY_RELATION_KINDS),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, id, json, kind, memory }) => runFeedbackCommand({
  operation: "link",
  id,
  relation: { kind, memory },
  dryRun,
}).pipe(Effect.flatMap((outcome) => emit(outcome, json)))).pipe(
  Command.withDescription("Relate Feedback to an existing Memory."),
);

const feedbackAdopt = Command.make("adopt", {
  id: Args.string("feedback-id"),
  to: Options.string("to").pipe(Options.withDescription("Exact repository ref adopted by this Feedback.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, id, json, to }) => runFeedbackCommand({
  operation: "adopt",
  id,
  to,
  dryRun,
}).pipe(Effect.flatMap((outcome) => emit(outcome, json)))).pipe(
  Command.withDescription("Adopt Feedback into one Roadmap, Feature, Use Case, or Engineering target."),
);

const feedbackRetire = Command.make("retire", {
  id: Args.string("feedback-id"),
  from: Options.string("from").pipe(Options.withDescription("Exact current repository ref to retire.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, from, id, json }) => runFeedbackCommand({
  operation: "retire",
  id,
  from,
  dryRun,
}).pipe(Effect.flatMap((outcome) => emit(outcome, json)))).pipe(
  Command.withDescription("Retire one current Feedback adoption while preserving its history."),
);

const feedbackClose = Command.make("close", {
  id: Args.string("feedback-id"),
  kind: Options.choice("kind", FEEDBACK_CLOSURE_KINDS),
  memory: Options.string("memory").pipe(Options.withDescription("Related Memory ID."), Options.optional),
  target: Options.string("target").pipe(Options.withDescription("Delivered repository ref."), Options.optional),
  proof: Options.string("proof").pipe(
    Options.atLeast(0),
    Options.withDescription("Closure evidence; repeat for each proof item."),
  ),
  canonical: Options.string("canonical").pipe(Options.withDescription("Canonical Feedback ID."), Options.optional),
  evidence: Options.string("evidence").pipe(
    Options.atLeast(0),
    Options.withDescription("Invalid-observation evidence; repeat for each item."),
  ),
  dependency: Options.string("dependency").pipe(Options.withDescription("Fixed external dependency."), Options.optional),
  version: Options.string("version").pipe(Options.withDescription("External fixed version."), Options.optional),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ canonical, dependency, dryRun, evidence, id, json, kind, memory, proof, target, version }) => {
  const memoryValue = Option.getOrUndefined(memory);
  const targetValue = Option.getOrUndefined(target);
  const canonicalValue = Option.getOrUndefined(canonical);
  const dependencyValue = Option.getOrUndefined(dependency);
  const versionValue = Option.getOrUndefined(version);
  const closure = {
    kind,
    ...(memoryValue === undefined ? {} : { memory: memoryValue }),
    ...(targetValue === undefined ? {} : { target: targetValue }),
    ...(proof.length === 0 ? {} : { proof }),
    ...(canonicalValue === undefined ? {} : { canonical: canonicalValue }),
    ...(evidence.length === 0 ? {} : { evidence }),
    ...(dependencyValue === undefined ? {} : { dependency: dependencyValue }),
    ...(versionValue === undefined ? {} : { version: versionValue }),
  };
  return runFeedbackCommand({ operation: "close", id, closure, dryRun }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
  );
}).pipe(Command.withDescription("Close Feedback with validated evidence."));

const feedbackReopen = Command.make("reopen", {
  id: Args.string("feedback-id"),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, id, json }) => runFeedbackCommand({ operation: "reopen", id, dryRun }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Reopen closed Feedback."));

const feedbackCheck = Command.make("check", { json: jsonOption }, ({ json }) =>
  runFeedbackCommand({ operation: "check" }).pipe(
    Effect.flatMap((outcome) => emit(outcome, json)),
  )).pipe(Command.withDescription("Validate Feedback, relations, closures, and migration provenance."));

const feedback = Command.make("feedback").pipe(
  Command.withDescription("Audit, relate, close, and validate legacy repository Feedback."),
  Command.withSubcommands([
    feedbackImport,
    feedbackExport,
    feedbackList,
    feedbackShow,
    feedbackLink,
    feedbackAdopt,
    feedbackRetire,
    feedbackClose,
    feedbackReopen,
    feedbackCheck,
  ]),
);

const memoryAdd = Command.make("add", {
  id: Args.string("memory-id"),
  title: Options.string("title"),
  kind: Options.choice("kind", MEMORY_KINDS),
  createdAt: Options.string("created-at").pipe(
    Options.withDescription("Creation date (YYYY-MM-DD); defaults to today."),
    Options.optional,
  ),
  body: Options.string("body").pipe(Options.withDescription("Markdown body path, or - for stdin.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ body, createdAt, dryRun, id, json, kind, title }) => Effect.all({
  body: readText(body),
  createdAt: Option.match(createdAt, {
    onNone: () => Clock.currentTimeMillis.pipe(Effect.map((millis) => new Date(millis).toISOString().slice(0, 10))),
    onSome: Effect.succeed,
  }),
}).pipe(
  Effect.flatMap(({ body: source, createdAt }) => runMemoryCommand({
    operation: "add",
    metadata: {
      format: "niceeval.memory/v1",
      id,
      title,
      createdAt,
      kind: kind === "problem"
        ? { type: kind, state: "open" }
        : kind === "decision"
          ? { type: kind, state: "adopted" }
          : { type: kind, state: "current" },
      promotions: [],
    },
    body: source,
    dryRun,
  })),
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Add one structured Memory."));

const memoryList = Command.make("list", { json: jsonOption }, ({ json }) =>
  runMemoryCommand({ operation: "list" }).pipe(Effect.flatMap((outcome) => emit(outcome, json)))).pipe(
  Command.withDescription("List structured and legacy Memory."),
);
const memoryShow = Command.make("show", {
  id: Args.string("memory-id"),
  json: jsonOption,
}, ({ id, json }) => runMemoryCommand({ operation: "show", id }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Show one Memory."));
const memorySearch = Command.make("search", {
  pattern: Args.string("pattern"),
  json: jsonOption,
}, ({ json, pattern }) => runMemoryCommand({ operation: "search", pattern }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Search Memory metadata and body text."));

const memoryAuthorSet = Command.make("set", {
  id: Args.string("memory-id"),
  body: Options.string("body").pipe(Options.withDescription("Markdown body path, or - for stdin.")),
  expectedOwnerDigest: Options.string("expected-owner-digest"),
  expectedAuthorDigest: Options.string("expected-author-digest"),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ body, dryRun, expectedAuthorDigest, expectedOwnerDigest, id, json }) => readText(body).pipe(
  Effect.flatMap((source) => runMemoryCommand({ operation: "author-set", id, body: source, expectedOwnerDigest, expectedAuthorDigest, dryRun })),
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Replace the author-owned Memory body while preserving managed history."));

const memoryAuthor = Command.make("author").pipe(
  Command.withDescription("Update author-owned Memory prose."),
  Command.withSubcommands([memoryAuthorSet]),
);

const memoryResolve = Command.make("resolve", {
  id: Args.string("memory-id"),
  kind: Options.choice("kind", PROBLEM_RESOLUTION_KINDS),
  proof: Options.string("proof").pipe(
    Options.atLeast(1),
    Options.withDescription("Resolution evidence; repeat for each proof item."),
  ),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, id, json, kind, proof }) => runMemoryCommand({
  operation: "resolve",
  id,
  resolution: { kind, proof },
  dryRun,
}).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Resolve one structured Problem Memory."));

const memoryReopen = Command.make("reopen", {
  id: Args.string("memory-id"),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, id, json }) => runMemoryCommand({ operation: "reopen", id, dryRun }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Reopen one resolved Problem Memory."));

const memorySupersede = Command.make("supersede", {
  id: Args.string("memory-id"),
  by: Options.string("by").pipe(Options.withDescription("Replacement Memory ID.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ by, dryRun, id, json }) => runMemoryCommand({ operation: "supersede", id, by, dryRun }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Supersede one Decision or Insight Memory."));

const memoryPromote = Command.make("promote", {
  id: Args.string("memory-id"),
  to: Options.string("to").pipe(Options.withDescription("Exact repository ref promoted by this Memory.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, id, json, to }) => runMemoryCommand({ operation: "promote", id, to, dryRun }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Promote Memory into one Roadmap, Feature, Use Case, or Engineering target."));

const memoryRetire = Command.make("retire", {
  id: Args.string("memory-id"),
  from: Options.string("from").pipe(Options.withDescription("Exact current repository ref to retire.")),
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, from, id, json }) => runMemoryCommand({ operation: "retire", id, from, dryRun }).pipe(
  Effect.flatMap((outcome) => emit(outcome, json)),
)).pipe(Command.withDescription("Retire one current Memory promotion while preserving its history."));

const memoryCheck = Command.make("check", { json: jsonOption }, ({ json }) =>
  runMemoryCommand({ operation: "check" }).pipe(
    Effect.flatMap((outcome) => emit(outcome, json)),
  )).pipe(Command.withDescription("Validate Memory state, promotions, and E2E regression references."));

const memory = Command.make("memory").pipe(
  Command.withDescription("Record, search, resolve, supersede, promote, and validate repository Memory."),
  Command.withSubcommands([
    memoryAdd,
    memoryList,
    memoryShow,
    memorySearch,
    memoryAuthor,
    memoryResolve,
    memoryReopen,
    memorySupersede,
    memoryPromote,
    memoryRetire,
    memoryCheck,
  ]),
);

const prNumberOption = Options.integer("pr").pipe(Options.withDescription("GitHub pull request number."));
const sourceOption = Options.string("source").pipe(Options.withDescription(
  "Managed draft path; when omitted, the command selects its matching Git-private draft.",
));
const baseOption = Options.string("base").pipe(Options.withDescription("Locked base ref or target branch."));
function runPr(input: unknown, json: boolean) {
  return Effect.matchEffect(prBodyCommandContribution.run(input), {
    onFailure: (error) => deliverTerminal({
      stdout: "",
      stderr: json
        ? `${JSON.stringify({ ok: false, error }, null, 2)}\n`
        : `${prBodyCommandContribution.renderError(error)}\n`,
      exitCode: 1,
    }),
    onSuccess: (outcome) => emit(
      outcome,
      json,
      prBodyCommandContribution.renderOutcome(outcome),
    ),
  });
}

const prInit = Command.make("init", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  base: baseOption.pipe(Options.optional),
  json: jsonOption,
}, ({ base, json, pr, source }) => runPr({
  command: "init",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  base: Option.getOrUndefined(base),
}, json)).pipe(Command.withDescription("Create or initialize a managed PR body draft."));

const prStatus = Command.make("status", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  json: jsonOption,
}, ({ json, pr, source }) => runPr({
  command: "status",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
}, json)).pipe(Command.withDescription("Inspect the local managed PR body draft without changing it."));

const prDiscard = Command.make("discard", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  json: jsonOption,
}, ({ json, pr, source }) => runPr({
  command: "discard",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
}, json)).pipe(Command.withDescription("Delete one local managed PR body draft without changing a remote PR."));

const prEditReset = Command.make("reset", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  json: jsonOption,
}, ({ json, pr, source }) => runPr({
  command: "edit",
  operation: "reset",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
}, json)).pipe(Command.withDescription("Clear authored content and refresh the managed template state."));

const prEditProblem = Command.make("problem", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  userGoal: Options.string("user-goal"),
  currentLimitation: Options.string("current-limitation"),
  requiredCapability: Options.string("required-capability"),
  userOutcome: Options.string("user-outcome"),
  json: jsonOption,
}, ({ currentLimitation, json, pr, requiredCapability, source, userGoal, userOutcome }) => runPr({
  command: "edit",
  operation: "problem",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  userGoal,
  currentLimitation,
  requiredCapability,
  userOutcome,
}, json)).pipe(Command.withDescription("Set the four required Problem fields."));

const prClosingIssueOption = Options.integer("issue").pipe(Options.withDescription("GitHub issue number."));
const prEditClosingIssueAdd = Command.make("add", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), issue: prClosingIssueOption, json: jsonOption,
}, ({ pr, source, issue, json }) => runPr({ command: "edit", operation: "closing-issue-add", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), issue }, json)).pipe(Command.withDescription("Add a GitHub closing keyword for one issue."));
const prEditClosingIssueRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), issue: prClosingIssueOption, json: jsonOption,
}, ({ pr, source, issue, json }) => runPr({ command: "edit", operation: "closing-issue-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), issue }, json)).pipe(Command.withDescription("Remove one GitHub closing issue reference."));
const prEditClosingIssue = Command.make("closing-issue").pipe(Command.withDescription("Maintain issue references that close when the PR merges."), Command.withSubcommands([prEditClosingIssueAdd, prEditClosingIssueRemove]));

const prCaseSectionOption = Options.choice("section", PR_BODY_CASE_SECTIONS).pipe(Options.withDescription("PR template section owned by this case."));
const prCaseDirectionOption = Options.choice("direction", PR_BODY_CASE_DIRECTIONS);
const prCaseNameOption = Options.string("name").pipe(Options.withDescription("Stable Case heading."));

const prEditCaseSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  section: prCaseSectionOption,
  direction: prCaseDirectionOption,
  name: prCaseNameOption,
  beforeInput: Options.string("before-input"),
  beforeOutput: Options.string("before-output"),
  afterInput: Options.string("after-input").pipe(Options.optional),
  afterOutput: Options.string("after-output"),
  userImpact: Options.string("user-impact"),
  language: Options.string("language").pipe(Options.optional),
  json: jsonOption,
}, ({
  afterInput,
  afterOutput,
  beforeInput,
  beforeOutput,
  direction,
  json,
  language,
  name,
  pr,
  section,
  source,
  userImpact,
}) => runPr({
  command: "edit",
  operation: "case-set",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  section,
  direction,
  name,
  beforeInput,
  beforeOutput,
  afterInput: Option.getOrUndefined(afterInput),
  afterOutput,
  userImpact,
  language: Option.getOrUndefined(language),
}, json)).pipe(Command.withDescription("Add or replace one structured Before/After/User impact case."));

const prEditCaseRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  section: prCaseSectionOption,
  direction: prCaseDirectionOption,
  name: prCaseNameOption,
  json: jsonOption,
}, ({ direction, json, name, pr, section, source }) => runPr({
  command: "edit",
  operation: "case-remove",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  section,
  direction,
  name,
}, json)).pipe(Command.withDescription("Remove one exact structured case and any newly empty headings."));

const prEditCase = Command.make("case").pipe(
  Command.withDescription("Maintain structured product-surface cases."),
  Command.withSubcommands([prEditCaseSet, prEditCaseRemove]),
);

const prEditUseCaseSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  direction: prCaseDirectionOption, name: prCaseNameOption,
  contract: Options.string("contract"), startingState: Options.string("starting-state"),
  action: Options.string("action"), result: Options.string("result"),
  explanation: Options.string("explanation"), language: Options.string("language").pipe(Options.optional), json: jsonOption,
}, ({ pr, source, direction, name, contract, startingState, action, result, explanation, language, json }) => runPr({
  command: "edit", operation: "use-case-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), direction, name, contract, startingState, action, result, explanation, language: Option.getOrUndefined(language),
}, json)).pipe(Command.withDescription("Add or replace one Added, Changed, or Removed canonical NiceEval Use Case."));

const prEditUseCaseRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), direction: prCaseDirectionOption, name: prCaseNameOption, json: jsonOption,
}, ({ pr, source, direction, name, json }) => runPr({ command: "edit", operation: "use-case-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), direction, name }, json)).pipe(Command.withDescription("Remove one exact Use Case entry from the draft."));

const prEditUseCase = Command.make("use-case").pipe(Command.withDescription("Maintain canonical Added/Changed/Removed NiceEval Use Cases."), Command.withSubcommands([prEditUseCaseSet, prEditUseCaseRemove]));

const prEditRecordNewWriteSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  action: Options.string("action"), result: Options.string("result"), json: jsonOption,
}, ({ pr, source, action, result, json }) => runPr({
  command: "edit", operation: "record-new-write-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), action, result,
}, json)).pipe(Command.withDescription("Set the public new-Record writer action and observed result."));
const prEditRecordNewWriteRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), json: jsonOption,
}, ({ pr, source, json }) => runPr({ command: "edit", operation: "record-new-write-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source) }, json)).pipe(Command.withDescription("Remove the new-Record writer case."));
const prEditRecordNewWrite = Command.make("new-write").pipe(
  Command.withDescription("Maintain the public action and result for writing a new Record."),
  Command.withSubcommands([prEditRecordNewWriteSet, prEditRecordNewWriteRemove]),
);

const prEditRecordExistingReadSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  action: Options.string("action"), result: Options.string("result"), json: jsonOption,
}, ({ pr, source, action, result, json }) => runPr({
  command: "edit", operation: "record-existing-read-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), action, result,
}, json)).pipe(Command.withDescription("Set the public existing-Record reader action and observed result."));
const prEditRecordExistingReadRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), json: jsonOption,
}, ({ pr, source, json }) => runPr({ command: "edit", operation: "record-existing-read-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source) }, json)).pipe(Command.withDescription("Remove the existing-Record reader case."));
const prEditRecordExistingRead = Command.make("existing-read").pipe(
  Command.withDescription("Maintain the public action and result for reading an existing Record."),
  Command.withSubcommands([prEditRecordExistingReadSet, prEditRecordExistingReadRemove]),
);

const prEditRecordUpgradeSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  version: Options.string("version").pipe(Options.withDescription("Dotted numeric version transition, for example 0.15 -> 0.16.")),
  beforeInput: Options.string("before-input"), beforeOutput: Options.string("before-output"),
  afterInput: Options.string("after-input"), afterOutput: Options.string("after-output"),
  safety: Options.string("safety"), userImpact: Options.string("user-impact"), evidence: Options.string("evidence"),
  json: jsonOption,
}, ({ pr, source, json, ...upgrade }) => runPr({
  command: "edit", operation: "record-upgrade-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), ...upgrade,
}, json)).pipe(Command.withDescription("Set the Record version, before/after recovery behavior, safety, impact, and evidence."));
const prEditRecordUpgradeRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), json: jsonOption,
}, ({ pr, source, json }) => runPr({ command: "edit", operation: "record-upgrade-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source) }, json)).pipe(Command.withDescription("Remove the Record upgrade or recovery case."));
const prEditRecordUpgrade = Command.make("upgrade").pipe(
  Command.withDescription("Maintain the public stored-data upgrade or recovery case."),
  Command.withSubcommands([prEditRecordUpgradeSet, prEditRecordUpgradeRemove]),
);

const prEditRecordPrivateSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  name: prCaseNameOption, before: Options.string("before"), after: Options.string("after"),
  userImpact: Options.string("user-impact"), json: jsonOption,
}, ({ pr, source, name, before, after, userImpact, json }) => runPr({
  command: "edit", operation: "record-private-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), name, before, after, userImpact,
}, json)).pipe(Command.withDescription("Add or replace one explicitly private persisted-data case."));
const prEditRecordPrivateRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional), name: prCaseNameOption, json: jsonOption,
}, ({ pr, source, name, json }) => runPr({ command: "edit", operation: "record-private-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), name }, json)).pipe(Command.withDescription("Remove one exact private persisted-data case."));
const prEditRecordPrivate = Command.make("private-persistence").pipe(
  Command.withDescription("Maintain private persisted data without presenting it as public Record schema."),
  Command.withSubcommands([prEditRecordPrivateSet, prEditRecordPrivateRemove]),
);

const prEditRecord = Command.make("record").pipe(
  Command.withDescription("Maintain Record write, read, upgrade, and separately identified private persistence cases."),
  Command.withSubcommands([prEditRecordNewWrite, prEditRecordExistingRead, prEditRecordUpgrade, prEditRecordPrivate]),
);

const prEditEnvironmentSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  direction: prCaseDirectionOption, name: prCaseNameOption,
  beforeInput: Options.string("before-input"), beforeOutput: Options.string("before-output"),
  afterInput: Options.string("after-input").pipe(Options.optional), afterOutput: Options.string("after-output").pipe(Options.optional),
  boundary: Options.string("boundary"), necessity: Options.string("necessity").pipe(Options.optional),
  securityImpact: Options.string("security-impact"), json: jsonOption,
}, ({ pr, source, direction, name, beforeInput, beforeOutput, afterInput, afterOutput, boundary, necessity, securityImpact, json }) => runPr({
  command: "edit", operation: "environment-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source),
  direction, name, beforeInput, beforeOutput, afterInput: Option.getOrUndefined(afterInput), afterOutput: Option.getOrUndefined(afterOutput),
  boundary, necessity: Option.getOrUndefined(necessity), securityImpact,
}, json)).pipe(Command.withDescription("Add or replace one environment-variable change with boundary, necessity, and security impact."));
const prEditEnvironmentRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  direction: prCaseDirectionOption, name: prCaseNameOption, json: jsonOption,
}, ({ pr, source, direction, name, json }) => runPr({ command: "edit", operation: "environment-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), direction, name }, json)).pipe(Command.withDescription("Remove one exact environment-variable change."));
const prEditEnvironment = Command.make("environment").pipe(
  Command.withDescription("Maintain Added, Changed, and Removed environment variables."),
  Command.withSubcommands([prEditEnvironmentSet, prEditEnvironmentRemove]),
);

const prTerminologyDirectionOption = Options.choice("direction", PR_BODY_TERMINOLOGY_DIRECTIONS);
const prEditTerminologySet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  direction: prTerminologyDirectionOption, name: prCaseNameOption,
  before: Options.string("before"), after: Options.string("after"), explanation: Options.string("explanation"),
  canonical: Options.string("canonical").pipe(Options.withDescription("Canonical docs/concepts.md#<Unicode-anchor> link.")), json: jsonOption,
}, ({ pr, source, direction, name, before, after, explanation, canonical, json }) => runPr({
  command: "edit", operation: "terminology-set", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), direction, name, before, after, explanation, canonical,
}, json)).pipe(Command.withDescription("Add or replace one preferred-term addition or removal."));
const prEditTerminologyRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional), source: sourceOption.pipe(Options.optional),
  direction: prTerminologyDirectionOption, name: prCaseNameOption, json: jsonOption,
}, ({ pr, source, direction, name, json }) => runPr({ command: "edit", operation: "terminology-remove", pr: Option.getOrUndefined(pr), source: Option.getOrUndefined(source), direction, name }, json)).pipe(Command.withDescription("Remove one exact preferred-term change."));
const prEditTerminology = Command.make("terminology").pipe(
  Command.withDescription("Maintain Added and Removed preferred terminology with canonical concepts links."),
  Command.withSubcommands([prEditTerminologySet, prEditTerminologyRemove]),
);

const prEditTestSet = Command.make("set", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  selector: Args.string("path#caseId"),
  behavior: Options.string("behavior"),
  entry: Options.string("entry"),
  assertion: Options.string("assertion"),
  escape: Options.string("escape"),
  regression: Options.string("regression").pipe(Options.optional),
  fragmentFrom: Options.string("fragment-from").pipe(Options.withDescription("Unique complete source line, or <BOF> for the file start."), Options.atLeast(0)),
  fragmentThrough: Options.string("fragment-through").pipe(Options.withDescription("Unique complete source line, or <EOF> for the file end."), Options.atLeast(0)),
  fragmentReason: Options.string("fragment-reason").pipe(Options.optional),
  sourceMode: Options.choice("source-mode", ["full", "link"] as const).pipe(
    Options.optional,
    Options.withDescription("How the PR presents test source; link emits immutable GitHub source and diff links."),
  ),
  json: jsonOption,
}, ({
  assertion,
  behavior,
  entry,
  escape,
  fragmentFrom,
  fragmentReason,
  fragmentThrough,
  json,
  regression,
  selector,
  pr,
  source,
  sourceMode,
}) => runPr({
  command: "edit",
  operation: "test-set",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  selector,
  behavior,
  entry,
  assertion,
  escape,
  regression: Option.getOrUndefined(regression),
  fragmentFrom,
  fragmentThrough,
  fragmentReason: Option.getOrUndefined(fragmentReason),
  sourceMode: Option.getOrUndefined(sourceMode),
}, json)).pipe(Command.withDescription("Add or replace one canonical test case narrative and its file source directive."));

const prEditTestRemove = Command.make("remove", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  selector: Args.string("path#caseId"),
  json: jsonOption,
}, ({ json, selector, pr, source }) => runPr({
  command: "edit",
  operation: "test-remove",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  selector,
}, json)).pipe(Command.withDescription("Remove one exact canonical test case narrative."));

const prEditTest = Command.make("test").pipe(
  Command.withDescription("Maintain test source directives."),
  Command.withSubcommands([prEditTestSet, prEditTestRemove]),
);

const prEditVerification = Command.make("verification", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  candidate: Options.string("candidate"),
  red: Options.string("red").pipe(Options.optional),
  green: Options.string("green"),
  repeatability: Options.string("repeatability"),
  fixedConditions: Options.string("fixed-conditions"),
  unitCount: Options.string("unit-count"),
  json: jsonOption,
}, ({ pr, source, json, red, ...receipt }) => runPr({
  command: "edit",
  operation: "verification",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  red: Option.getOrUndefined(red),
  ...receipt,
}, json)).pipe(Command.withDescription("Set the shared candidate and validation receipt required by the PR template."));

const prEdit = Command.make("edit").pipe(
  Command.withDescription("Edit a managed PR draft without writing Markdown directly."),
  Command.withSubcommands([
    prEditReset,
    prEditProblem,
    prEditClosingIssue,
    prEditUseCase,
    prEditCase,
    prEditRecord,
    prEditEnvironment,
    prEditTerminology,
    prEditTest,
    prEditVerification,
  ]),
);

const prRender = Command.make("render", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  out: Options.string("out").pipe(Options.optional),
  json: jsonOption,
}, ({ json, out, pr, source }) => runPr({
  command: "render",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  out: Option.getOrUndefined(out),
}, json)).pipe(Command.withDescription("Expand directives and render final Markdown."));

const prCheck = Command.make("check", {
  pr: prNumberOption.pipe(Options.optional),
  source: sourceOption.pipe(Options.optional),
  remote: Options.boolean("remote").pipe(
    Options.withDefault(false),
    Options.withDescription("Compare body and head with GitHub; local validation is the default."),
  ),
  json: jsonOption,
}, ({ json, pr, remote, source }) => runPr({
  command: "check",
  pr: Option.getOrUndefined(pr),
  source: Option.getOrUndefined(source),
  remote,
}, json)).pipe(Command.withDescription("Validate a PR body locally, with optional remote comparison."));

const prApply = Command.make("apply", {
  pr: prNumberOption,
  source: sourceOption.pipe(Options.optional),
  json: jsonOption,
}, ({ json, pr, source }) => runPr({
  command: "apply",
  pr,
  source: Option.getOrUndefined(source),
}, json)).pipe(Command.withDescription("Verify pushed HEAD and update an existing PR body."));

const prCreate = Command.make("create", {
  source: sourceOption.pipe(Options.optional),
  title: Options.string("title"),
  base: baseOption.pipe(Options.optional),
  json: jsonOption,
}, ({ base, json, source, title }) => runPr({
  command: "create",
  source: Option.getOrUndefined(source),
  title,
  base: Option.getOrUndefined(base),
}, json)).pipe(Command.withDescription("Create, apply, and verify a PR from pushed HEAD."));

const prBody = Command.make("body").pipe(
  Command.withDescription("Edit, compile, validate, and publish NiceEval pull request bodies."),
  Command.withSubcommands([prInit, prStatus, prDiscard, prEdit, prRender, prCheck, prApply, prCreate]),
);
const pr = Command.make("pr").pipe(
  Command.withDescription("Maintain pull requests."),
  Command.withSubcommands([prBody]),
);

const docsContributions = Object.freeze([
  featureCommandContribution,
  useCaseCommandContribution,
  testCommandContribution,
  traceCommandContribution,
  designCommandContribution,
  researchCommandContribution,
  termsCommandContribution,
  workCommandContribution,
  referenceCommandContribution,
  diffCodeCommandContribution,
  siteCommandContribution,
] as const);
const docs = makeDocsCommand(docsContributions, deliverTerminal);

const examplesCheck = Command.make("check", {
  name: Args.string("tier-name").pipe(Args.optional),
  json: jsonOption,
}, ({ json, name }) => checkExamples(Option.getOrUndefined(name)).pipe(
  Effect.flatMap((receipt) => emit(receipt, json)),
)).pipe(Command.withDescription("Check example tier state without writing Git objects or files."));
const examplesApply = Command.make("apply", {
  name: Args.string("tier-name").pipe(Args.optional),
  json: jsonOption,
}, ({ json, name }) => {
  const selected = Option.getOrUndefined(name);
  return syncExamples(selected).pipe(Effect.flatMap((receipt) => emit(receipt, json)));
}).pipe(
  Command.withDescription("Synchronize all or one named example tier."),
);
const examplesSync = Command.make("sync").pipe(
  Command.withDescription("Check or synchronize example tier chains."),
  Command.withSubcommands([examplesCheck, examplesApply]),
);
const examples = Command.make("examples").pipe(
  Command.withDescription("Maintain runnable examples."),
  Command.withSubcommands([examplesSync]),
);

const link = Command.make("link", {
  project: Args.string("project-directory"),
  json: jsonOption,
}, ({ json, project }) => linkDownstreamCandidate(project).pipe(
  Effect.flatMap((receipt) => emit(receipt, json)),
)).pipe(Command.withDescription("Build and link the current NiceEval candidate into another project."));
const packageDocsIndex = Command.make("docs-index", {
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, json }) => generateBundledIndex(dryRun).pipe(
  Effect.flatMap((receipt) => emit(receipt, json)),
)).pipe(Command.withDescription("Generate the package-owned bundled documentation index."));
const packageSurface = Command.make("package").pipe(
  Command.withDescription("Build package-owned generated surfaces."),
  Command.withSubcommands([packageDocsIndex]),
);

const repositoryCheck = Command.make("check", { json: jsonOption }, ({ json }) =>
  checkRepository().pipe(Effect.flatMap((receipt) => emit(receipt, json)))).pipe(
  Command.withDescription("Check hooks and host prerequisites without writing."),
);
const repositoryApply = Command.make("apply", {
  dryRun: dryRunOption,
  json: jsonOption,
}, ({ dryRun, json }) => setupRepositoryEnvironment(dryRun).pipe(
  Effect.flatMap((receipt) => emit(receipt, json)),
)).pipe(Command.withDescription("Apply repository-local hooks after prerequisite checks."));
const repositorySetup = Command.make("setup").pipe(
  Command.withDescription("Check or apply repository setup."),
  Command.withSubcommands([repositoryCheck, repositoryApply]),
);
const repository = Command.make("repository").pipe(
  Command.withDescription("Maintain repository-local setup."),
  Command.withSubcommands([repositorySetup]),
);

function emitCanonicalReceipt(receipt: unknown) {
  return deliverTerminal({ stdout: `${canonicalJson(receipt)}\n`, stderr: "", exitCode: 0 });
}

function runPreviewReceipt<A, R>(effect: Effect.Effect<A, PreviewError, R>) {
  return Effect.matchEffect(effect, {
    onFailure: (error) => deliverTerminal({ stdout: "", stderr: `${renderPreviewError(error)}\n`, exitCode: 1 }),
    onSuccess: emitCanonicalReceipt,
  });
}

const previewBuild = Command.make("build", {
  local: Options.boolean("local").pipe(
    Options.withDefault(false),
    Options.withDescription("Run explicitly as a local build without reading or fabricating Netlify identity."),
  ),
}, ({ local }) => runPreviewReceipt(buildPreview({ local }))).pipe(
  Command.withDescription("Build and seal the pinned Preview repository with the exact current NiceEval tarball."),
);

const previewAccept = Command.make("accept", {
  input: inputOption.pipe(Options.withDescription(
    "JSON input path, or - for stdin; contains the build receipt, read-only Netlify deploy metadata, GitHub current head, and current-head check.",
  )),
}, ({ input }) => readJson(input).pipe(
  Effect.flatMap((value) => runPreviewReceipt(acceptPreview(value))),
)).pipe(Command.withDescription("Verify an immutable deployed Preview manifest and emit an acceptance receipt."));

const preview = Command.make("preview").pipe(
  Command.withDescription("Build and accept NiceEval pull request and production previews."),
  Command.withSubcommands([previewBuild, previewAccept]),
);

const root = Command.make("niceeval-repo").pipe(
  Command.withDescription("NiceEval repository maintenance commands."),
  Command.withSubcommands([feedback, memory, pr, docs, examples, link, packageSurface, repository, preview]),
);

const live = Layer.mergeAll(
  NodeServices.layer,
  OwnedProcessLive,
  NodeFeedbackStoreLive(ROOT),
  NodeMemoryStoreLive(ROOT),
  makeNodePrLive(ROOT).pipe(Layer.provide(NodeServices.layer)),
);

Command.run(root, { version: "1" }).pipe(
  Effect.catch((error) => deliverTerminal({ stdout: "", stderr: `${renderUnhandledError(error)}\n`, exitCode: 1 })),
  Effect.provide(live),
  NodeRuntime.runMain,
);
